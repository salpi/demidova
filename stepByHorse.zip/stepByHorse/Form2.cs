﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public bool closeButton;
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {            
            Program.form1.label1.Text = textBox1.Text.Trim();
            Program.form1.label2.Text = textBox2.Text.Trim();
            Program.form1.playBlack = checkBox1.Checked;
            if (checkBox1.Checked)
                Program.form1.labelColor.Text = "Играем черными";
            else
                Program.form1.labelColor.Text = "Играем белыми";          
            this.Close();
            closeButton = false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            closeButton = false;
            textBox1.Text = Program.form1.label1.Text;
            textBox2.Text = Program.form1.label2.Text;
            checkBox1.Visible = false;
            checkBox1.Checked = Program.form1.checkBoxBlack.Checked;
            checkBox1.Checked = Program.form1.playBlack; 
            if (!Program.form1.isLocal)
                checkBox1.Visible = true;
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason==CloseReason.UserClosing)
                closeButton = true;

        }
    }
}
