﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public int curStep;
        public bool isLocal;
        

        private void TestGamePosition()
        {
            game = new Part();
            curStep = -1;
            game.Places[0] = new Place(2, 3, 0, 1);
            game.Places[1] = new Place(2, 4, 1, 0);
            game.Places[2] = new Place(2, 5, 2, 0);
            game.Places[3] = new Place(2, 2, 3, 0);
            game.Places[4] = new Place(2, 1, 4, 1);
            game.Places[5] = new Place(2, 5, 5, 0);
            game.Places[6] = new Place(2, 4, 6, 0);
            game.Places[7] = new Place(2, 3, 7, 1);
            for (int i = 8; i < 16; i++)
            game.Places[i] = new Place(2, 6, i, 1);

            game.Places[56] = new Place(1, 3, 56, 1);
            game.Places[57] = new Place(1, 4, 57, 0);
            game.Places[58] = new Place(1, 5, 58, 0);
            game.Places[59] = new Place(1, 2, 59, 0);
            game.Places[60] = new Place(1, 1, 60, 1);
            game.Places[61] = new Place(1, 5, 61, 0);
            game.Places[62] = new Place(1, 4, 62, 0);
            game.Places[63] = new Place(1, 3, 63, 1);
            for (int i = 48; i < 56; i++)
              game.Places[i] = new Place(1, 6, i, 1);
            label2.Text = "Player1";
            label1.Text = "";
            labelColor.Text = "Играем локально";
            richTextBox1.Text = "История сообщений";
            textBoxMessage.Text = "Ваше сообщение";
            labelWhomStep.Text = "Чей ход";
            isLocal = true;
            
        }

        private void StartGamePosition()
        {
            game = new Part();
            curStep = -1;
            game.Places[0] = new Place(2, 3, 0, 1);
            game.Places[1] = new Place(2, 4, 1, 0);
            game.Places[2] = new Place(2, 5, 2, 0);
            game.Places[3] = new Place(2, 2, 3, 0);
            game.Places[4] = new Place(2, 1, 4, 1);
            game.Places[5] = new Place(2, 5, 5, 0);
            game.Places[6] = new Place(2, 4, 6, 0);
            game.Places[7] = new Place(2, 3, 7, 1);
            for (int i = 8; i < 16; i++)
                game.Places[i] = new Place(2, 6, i, 1);

            game.Places[56] = new Place(1, 3, 56, 1);
            game.Places[57] = new Place(1, 4, 57, 0);
            game.Places[58] = new Place(1, 5, 58, 0);
            game.Places[59] = new Place(1, 2, 59, 0);
            game.Places[60] = new Place(1, 1, 60, 1);
            game.Places[61] = new Place(1, 5, 61, 0);
            game.Places[62] = new Place(1, 4, 62, 0);
            game.Places[63] = new Place(1, 3, 63, 1);
            for (int i = 48; i < 56; i++)
                game.Places[i] = new Place(1, 6, i, 1);
        }
        //------->Првоека шаха
        //s1 - для опеределения цвета ходящих
        private bool Check(Place s1)
        {
            Place pl2 = new Place(1, 1, 1, 1);
            Place pl1 = new Place(1, 1, 1, 1);
            //Шах для белых

            if (s1.Color == 1)
            {
                for (int i = 0; i < game.Places.Length; i++)
                {
                    if (game.Places[i].Type == 1 && game.Places[i].Color == 1)
                    {
                        pl2 = game.Places[i];
                        break;
                    }
                }
                for (int i = 0; i < game.Places.Length; i++)
                {
                    if ((game.Places[i].Color != 1))
                    {
                        pl1 = game.Places[i];
                        if (ValidateStep(new Step(pl1, pl2, 1, 1, pl1)))
                            return true;
                    }
                }
            }
            else
            {
                //Шах для черных
                for (int i = 0; i < game.Places.Length; i++)
                {
                    if (game.Places[i].Type == 1 && game.Places[i].Color == 2)
                    {
                        pl2 = game.Places[i];
                        break;
                    }
                }
                for (int i = 0; i < game.Places.Length; i++)
                {
                    if ((game.Places[i].Color != 2))
                    {
                        pl1 = game.Places[i];
                        if (ValidateStep(new Step(pl1, pl2, 1, 1, pl1)))
                            return true;
                    }
                }
            }
            return false;
        }
        //<-------Првоека шаха

        private bool ValidateStep(Step step)
        {
            bool res = false;
            //Определение типа хода
            if (step.s1.Color != step.s2.Color && step.s2.Type != 0)
                step.type = 2;
            else
                step.type = 1;
            if (step.s1.Type == 0)
                return false;
            //Король
            if (step.s1.Type == 1)
            {
                if (Math.Abs(step.s2.getX() - step.s1.getX()) <= 1)
                    if (Math.Abs(step.s2.getY() - step.s1.getY()) <= 1)
                    {
                        if (step.s2.Type == 0)
                            res = true;
                        if (step.s2.Type != 0 && step.s2.Color != step.s1.Color)
                            res = true;
                        if (true)
                            step.s12.Prop = 0;
                        if (!res)
                            return false;
                    
                        return true;
                    }
                //Рокировка
                if (step.s1.Prop == 1 && step.s1.getY() == step.s2.getY() && step.s2.Prop == 1
                    && step.s2.Type == 3 && step.s1.Color == step.s2.Color && step.s1.getX() != step.s2.getX())
                {
                    int xi = 0;
                    if (step.s1.getX() > step.s2.getX())
                        xi = -1;
                    if (step.s1.getX() < step.s2.getX())
                        xi = 1;
                    int num;
                    int ix = xi;
                    num = step.s1.Num + ix;
                    for (; step.s2.Num != num; )
                    {
                        if (game.Places[num].Type != 0)
                            return false;
                        ix += xi;
                        num = step.s1.Num + ix;
                    }
                    if (step.s1.getX() > step.s2.getX())
                        xi = -1;
                    if (step.s1.getX() < step.s2.getX())
                        xi = 1;
                    if (Check(game.Places[step.s1.Num]))
                    {
                        return false;
                    }
                    Place store = new Place(game.Places[step.s1.Num + xi]);
                    game.Places[step.s1.Num + xi] = new Place(game.Places[step.s1.Num]);
                    game.Places[step.s1.Num + xi].Num = store.Num;
                    game.Places[step.s1.Num].Type = 0;

                    if (Check(store))
                    {
                        game.Places[step.s1.Num].Type = 1;
                        game.Places[step.s1.Num + xi] = new Place(store);
                        return false;
                    }
                    game.Places[step.s1.Num].Type = 1;
                    game.Places[step.s1.Num + xi] = new Place(store);
                    num = step.s1.Num + 2 * xi;
                    step.s12.Num = num;
                    step.s12.Prop = 2;

                    num = step.s1.Num + xi;
                    step.s22.Num = num;
                    step.s22.Prop = 0;
                    return true;
                }
                return false;
            }
            //Ладья
            if (step.s1.Type == 3)
            {
                if (step.s1.Color == step.s2.Color && step.s2.Type != 0)
                    return false;
                if (step.s1.getX() == step.s2.getX() || step.s1.getY() == step.s2.getY())
                {
                    int xi = 0;
                    if (step.s1.getX() > step.s2.getX())
                        xi = -1;
                    if (step.s1.getX() < step.s2.getX())
                        xi = 1;
                    int yi = 0;
                    if (step.s1.getY() > step.s2.getY())
                        yi = -1;
                    if (step.s1.getY() < step.s2.getY())
                        yi = 1;

                    int num;
                    int ix = xi, iy = yi;
                    num = (step.s1.getY() + iy) * 8 + step.s1.getX() + ix;
                    for (; step.s2.Num != num; )
                    {
                        if (game.Places[num].Type != 0)
                            return false;
                        ix += xi;
                        iy += yi;
                        num = (step.s1.getY() + iy) * 8 + step.s1.getX() + ix;
                    }
                    step.s12.Prop = 0;
                    return true;
                }
                return false;
            }
            //Пешка
            if (step.s1.Type == 6)
            {
                if (step.s1.Color == 1 && (step.s2.getY() - step.s1.getY()) == -1)
                {
                    if ((step.s2.getX() == step.s1.getX()) && (step.s2.Type == 0))
                        res = true;
                    if ((step.s2.getX() != step.s1.getX()) && step.s2.Type != 0 && (step.s1.Color != step.s2.Color))
                        res = true;
                    if (res) step.s12.Prop = 0;
                    if (step.s2.getY() == 0)
                    {
                        step.s12.Type = 2;
                    }
                    return res;
                }
                if ((step.s1.Color == 1) && ((step.s2.getY() - step.s1.getY()) == -2) && (step.s1.Prop == 1))
                {
                    if (step.s2.Type == 0)
                        res = true;
                    if (game.Places[step.s1.getY() - 1].Type == 0)
                        res = true;
                    if (res) step.s12.Prop = 0;
                    return res;
                }


                if (step.s1.Color == 2 && (step.s2.getY() - step.s1.getY()) == 1)
                {
                    if ((step.s2.getX() == step.s1.getX()) && (step.s2.Type == 0))
                        res = true;
                    if ((step.s2.getX() != step.s1.getX()) && step.s2.Type != 0 && (step.s1.Color != step.s2.Color))
                        res = true;
                    if (res) step.s12.Prop = 0;
                    if (step.s2.getY() == 7)
                    {
                        step.s12.Type = 2;
                    }
                    return res;
                }
                if ((step.s1.Color == 2) && ((step.s2.getY() - step.s1.getY()) == 2) && (step.s1.Prop == 1))
                {
                    if (step.s2.Type == 0)
                        res = true;
                    if (game.Places[step.s1.getY() - 1].Type == 0)
                        res = true;
                    if (res) step.s12.Prop = 0;
                    return res;
                }

            }
            //Ферзь
            if (step.s1.Type == 2)
            {
                if (step.s1.Color == step.s2.Color && step.s2.Type != 0)
                    return false;
                if (step.s1.getX() != step.s2.getX() && step.s1.getY() != step.s2.getY())
                {
                    if (Math.Abs(step.s1.getX() - step.s2.getX()) == Math.Abs(step.s1.getY() - step.s2.getY()))
                    {
                        int xi = step.s1.getX() - step.s2.getX() > 0 ? -1 : 1;
                        int yi = step.s1.getY() - step.s2.getY() > 0 ? -1 : 1;
                        int num;
                        for (int ix = xi, iy = yi; Math.Abs(ix) < Math.Abs(step.s1.getX() - step.s2.getX()); ix += xi, iy += yi)
                        {
                            num = (step.s1.getY() + iy) * 8 + step.s1.getX() + ix;
                            if (game.Places[num].Type != 0)
                                return false;
                        }
                        return true;
                    }
                }
                if (step.s1.getX() == step.s2.getX() || step.s1.getY() == step.s2.getY())
                {
                    int xi = 0;
                    if (step.s1.getX() > step.s2.getX())
                        xi = -1;
                    if (step.s1.getX() < step.s2.getX())
                        xi = 1;
                    int yi = 0;
                    if (step.s1.getY() > step.s2.getY())
                        yi = -1;
                    if (step.s1.getY() < step.s2.getY())
                        yi = 1;

                    int num;
                    int ix = xi, iy = yi;
                    num = (step.s1.getY() + iy) * 8 + step.s1.getX() + ix;
                    for (; step.s2.Num != num; )
                    {
                        if (game.Places[num].Type != 0)
                            return false;
                        ix += xi;
                        iy += yi;
                        num = (step.s1.getY() + iy) * 8 + step.s1.getX() + ix;
                    }
                    return true;
                }
                if (step.s1.Color == step.s2.Color && step.s2.Type != 0)
                    return false;
                if (step.s1.getX() != step.s2.getX() && step.s1.getY() != step.s2.getY())
                {
                    if (Math.Abs(step.s1.getX() - step.s2.getX()) == Math.Abs(step.s1.getY() - step.s2.getY()))
                    {
                        int xi = step.s1.getX() - step.s2.getX() > 0 ? -1 : 1;
                        int yi = step.s1.getY() - step.s2.getY() > 0 ? -1 : 1;
                        int num;
                        for (int ix = xi, iy = yi; Math.Abs(ix) < Math.Abs(step.s1.getX() - step.s2.getX()); ix += xi, iy += yi)
                        {
                            num = (step.s1.getY() + iy) * 8 + step.s1.getX() + ix;
                            if (game.Places[num].Type != 0)
                                return false;
                        }
                        return true;
                    }
                    return false;
                }
                return false;
            }

            //Слон
            if (step.s1.Type == 5)
            {
                if (step.s1.Color == step.s2.Color && step.s2.Type != 0)
                    return false;
                if (step.s1.getX() != step.s2.getX() && step.s1.getY() != step.s2.getY())
                {
                    if (Math.Abs(step.s1.getX() - step.s2.getX()) == Math.Abs(step.s1.getY() - step.s2.getY()))
                    {
                        int xi = step.s1.getX() - step.s2.getX() > 0 ? -1 : 1;
                        int yi = step.s1.getY() - step.s2.getY() > 0 ? -1 : 1;
                        int num;
                        for (int ix = xi, iy = yi; Math.Abs(ix) < Math.Abs(step.s1.getX() - step.s2.getX()); ix += xi, iy += yi)
                        {
                            num = (step.s1.getY() + iy) * 8 + step.s1.getX() + ix;
                            if (game.Places[num].Type != 0)
                                return false;
                        }
                        return true;
                    }
                }
                return false;
            }
            //Конь
            if (step.s1.Type == 4)
            {
                if (step.s1.Color == step.s2.Color && step.s2.Type != 0)
                    return false;
                int xi = Math.Abs(step.s1.getX() - step.s2.getX());
                int yi = Math.Abs(step.s1.getY() - step.s2.getY());
                if ((xi == 2 && yi == 1) || (yi == 2 && xi == 1))
                {
                    return true;
                }
            }
            return false;
        }
        //--------->Возврат хода
        public void ReturnStep(int c, bool rmv)
        {
            if (c < 0)
            {
                for (int i = 0; i > c && game.History.Count > curStep && curStep >= 0; i--)
                {
                    Place s1, s2;
                    if (rmv)
                    {
                        for (curStep++; curStep < game.History.Count; curStep++)
                            ReturnStep(1, false);
                        curStep--;
                    }
                    
                    s1 = game.History[curStep].s1;
                    s2 = game.History[curStep].s2;
                    game.Places[s1.Num] = new Place(s1);
                    game.Places[s2.Num] = new Place(s2);
                    if (game.History[curStep].s12.Prop == 2)
                    {
                        int xi = 0;
                        if (s1.getX() > s2.getX())
                            xi = -1;
                        if (s1.getX() < s2.getX())
                            xi = 1;
                        int num;
                        int ix = xi;
                        num = s1.Num + ix;
                        for (; s2.Num != num; )
                        {
                            game.Places[num].Type = 0;
                            ix += xi;
                            num = s1.Num + ix;
                        }
                    }
                    if (rmv)
                    {
                        game.History.RemoveAt(game.History.Count - 1);
                    }
                    else
                        curStep--;
                    //
                }
            }
            else if (c > 0)
            {
                curStep++;
                for (int i = 0; i < c && game.History.Count > curStep && curStep >= 0; i++)
                {
                    Place s1, s2, s12, s22;
                    s1 = game.History[curStep].s1;
                    s2 = game.History[curStep].s2;
                    s12 = game.History[curStep].s12;
                    s22 = game.History[curStep].s22;
                    game.Places[s1.Num] = new Place(s2);
                    game.Places[s1.Num].Num = s1.Num;
                    game.Places[s2.Num] = new Place(s1);
                    game.Places[s2.Num].Num = s2.Num;
                    if (s12.Prop == 2)
                    {
                        game.Places[s1.Num].Type = 0;
                        game.Places[s2.Num].Type = 0;
                        game.Places[s12.Num] = new Place(s12);
                        game.Places[s22.Num] = new Place(s22);
                    }
                    curStep++;
                    //game.History.RemoveAt(game.History.Count - 1);
                }
                if (curStep <= game.History.Count)
                    curStep--;
            }
        }
        //<------Возврат хода
    }
}