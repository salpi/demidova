﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Collections.Specialized;
using Newtonsoft.Json;
using System.Resources;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private Timer aTimer;
        Point startPoint;
        MouseEventArgs bm;
        Part game;
        int color = 1;
        Place moveFig;
        Bitmap pictBox;
        public bool playBlack;
        AboutBox1 msg;
        //string url = "http://subdomain.test1.ru/";
        string url = "http://tuside.pe.hu/chess/indexchess.php";
        
        public Form1()
        {
            InitializeComponent();
            aTimer = new Timer();
            game = new Part();
            isLocal = true;
            moveFig = new Place(0, 0, 0, 0);
            msg = new AboutBox1();
        }

       

        private void button2_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(pictureBox1.Image);
            bmp.Save("saveBitmap.png", System.Drawing.Imaging.ImageFormat.Png);
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            
            startPoint = e.Location;
            startPoint = XYPlaceOnDesktop(startPoint);
            int i = DetectPlaceByXy(startPoint);
            if (!isLocal && curStep < (game.History.Count-1)&&curStep>=-1)
            {
                aTimer.Start();
                return;
            }
            if (i < 0)
            {
                aTimer.Start();
                return;
            }
            moveFig = game.Places[i];
            if (curStep > -1 && curStep < game.History.Count&& moveFig.Color == game.History[curStep].s1.Color)
            {
                aTimer.Start();
                return;
            }
            aTimer.Stop();
            int c = 1;
            if (playBlack)
                c = 2;

            if (!isLocal && moveFig.Type > 0 && moveFig.Color != c)
            {
                aTimer.Start();
                return;
            }
            UpdateBoard();
            timer1.Start();
        }
        private Point ConvertXYfromScreen(Point scr)
        {
            Bitmap b = Properties.Resources.green_bg_w;
            float k1 = (b.Width > pictureBox1.Width) ? (float)b.Width / pictureBox1.Width : 1;
            float k2 = (b.Width > pictureBox1.Width) ? (float)b.Height / pictureBox1.Height : 1;
            //float k = pictureBox1.Width > pictureBox1.Height ? k2 : k1;
            k1 = k2 = 1;
            scr.X = (int)(scr.X * k1) - 25;
            scr.Y = (int)(scr.Y * k2) - 25;
            return scr;
        }
        private int DetectPlaceByXy(Point scr)
        {
            Bitmap b = Properties.Resources.fer_w;
            Bitmap bg = Properties.Resources.green_bg_wall;
            if (scr.X < 60 || scr.Y < 60)
                return -1;
            int x = (scr.X - 60) / (b.Width - 10);
            int y = (scr.Y - 60) / (b.Height - 10);
            int res = y * 8 + x;
            if (res > 63 || res < 0)
                return -1;
            if (color == 2)
            {
                res = 7 - x + (7 - y) * 8;
            }
            return res;
        }
        private Point DetectXyByPlace(int i)
        {
            Point scr = new Point();
            Bitmap b = Properties.Resources.fer_w;
            int w = Properties.Resources.green_bg_ball.Width;
            int h = Properties.Resources.green_bg_ball.Height;
            scr.X = (i % 8) * (b.Width - 10) + 60;
            scr.Y = i / 8 * (b.Height - 10) + 60;
            if (color == 2)
            {
                scr.X = -scr.X + w - (b.Width - 10);
                scr.Y = -scr.Y + h - (b.Height - 10);
            }
            return scr;
        }
        private Point XYPlaceOnDesktop(Point scr)
        {
            Bitmap b = Properties.Resources.green_bg_wall;
            PictureBox pb = pictureBox1;
            int minpb = pb.Width < pb.Height ? pb.Width : pb.Height;
            int minb = b.Width < b.Height ? b.Width : b.Height;
            float k = (float)minb / minpb;

            scr.X = (int)((scr.X - (float)(pb.Width - (float)b.Width / k) / 2) * k);
            scr.Y = (int)((scr.Y - (float)(pb.Height - (float)b.Height / k) / 2) * k);

            return scr;
        }


        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            bm = e;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // StartGamePosition();
            TestGamePosition();
            UpdateBoard();
        }
        private void PainBoard(object sender, EventArgs e)
        {
            Bitmap bmp = Properties.Resources.green_bg_b;
            Graphics myGraphic = Graphics.FromImage(bmp);
            Bitmap pic;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if ((j + i) % 2 == 0)
                        pic = Properties.Resources.green_white_cell;
                    else
                        pic = Properties.Resources.green_black_cell;
                    myGraphic.DrawImage(pic, i * 110 + 60, j * 110 + 60, 110, 110);

                }
            }
            myGraphic.Dispose();
            pictureBox1.Image = bmp;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (bm.Button == MouseButtons.Left)
            {
                //Pen drawPen = new Pen(Color.White, 12);

                Point movePoint = bm.Location;
                movePoint = XYPlaceOnDesktop(movePoint);
                // UpdateBoard();
                //Bitmap bmp = new Bitmap(pictureBox1.Image);
                Bitmap bmp = new Bitmap(pictBox);
                Graphics g = Graphics.FromImage(bmp);
                //Graphics g = pictureBox1.CreateGraphics();

                //g.DrawLine(drawPen, startPoint, movePoint);
                //startPoint = movePoint;

                //drawPen.Dispose();

                Bitmap pic = SwitchPicByType(moveFig);
                if (pic == null)
                    return;
                pic.MakeTransparent(Color.White);
                g.DrawImage(pic, movePoint.X - pic.Width / 2, movePoint.Y - pic.Height / 2, pic.Width, pic.Height);
                g.Dispose();
                pictureBox1.Image = bmp;
                pictureBox1.Invalidate();

            }

        }
        private void UpdateBoard()
        {
            Point pos;
            Bitmap bmp, pic;
            if (color == 1)
                bmp = Properties.Resources.green_bg_wall;
            else
                bmp = Properties.Resources.green_bg_ball;

            Graphics g = Graphics.FromImage(bmp);

            for (int i = 0; i < game.Places.Length; i++)
            {
                pic = SwitchPicByType(game.Places[i]);
                if (pic != null)
                {
                    pic.MakeTransparent(Color.White);
                    pos = DetectXyByPlace(i);
                    g.DrawImage(pic, pos.X, pos.Y, pic.Width, pic.Height);
                }
            }
            g.Dispose();
            pictureBox1.Image = bmp;
            pictBox = new Bitmap(bmp);
            pictureBox1.Invalidate();
            if (curStep == -1)
            {
                labelWhomStep.Text = "Чей ход";
            }
            
        }
        private void ViewHistory()
        {
            RichTextBox r = richTextBoxHistory;
            r.Text = "";
            
            int len=0,lsel=0;
            string anot="";            
            for (int i = 0; i < game.History.Count; i++)
            {
                anot=game.History[i].getNotation();
                if (i == curStep)
                {
                    len = r.Text.Length;
                    r.Text += anot + "; ";
                    lsel = anot.Length;                    
                }
                else
                {                    
                    r.Text += anot + "; ";                    
                }                                
            }
            r.SelectionStart=len;
            r.SelectionLength = lsel;      
            r.SelectionColor = Color.Brown;
            if (curStep > -1) {
                if (game.History[curStep].s1.Color == 1)
                    labelWhomStep.Text = "Ход черных";
                else
                    labelWhomStep.Text = "Ход белых";
            }


        }
        private Bitmap SwitchPicByType(Place p)
        {
            Bitmap pic = null;
            if (p.Color == 1)
            {
                switch (p.Type)
                {
                    case 1: pic = Properties.Resources.kor_w; break;
                    case 2: pic = Properties.Resources.fer_w; break;
                    case 3: pic = Properties.Resources.lad_w; break;
                    case 4: pic = Properties.Resources.kon_w; break;
                    case 5: pic = Properties.Resources.off_w; break;
                    case 6: pic = Properties.Resources.pes_w; break;
                }
            }
            else
            {
                switch (p.Type)
                {
                    case 1: pic = Properties.Resources.kor_b; break;
                    case 2: pic = Properties.Resources.fer_b; break;
                    case 3: pic = Properties.Resources.lad_b; break;
                    case 4: pic = Properties.Resources.kon_b; break;
                    case 5: pic = Properties.Resources.off_b; break;
                    case 6: pic = Properties.Resources.pes_b; break;
                }
            }
            return pic;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            aTimer.Stop();
            timer1.Stop();
            if (!isLocal && curStep < (game.History.Count-1)&&curStep >= -1)
            {
                aTimer.Start();
                return;
            }
            if (curStep > -1 && curStep < game.History.Count && moveFig.Color == game.History[curStep].s1.Color)
            {
                aTimer.Start();
                return;
            }            
            int c = 1;
            if (playBlack)
                c = 2;

            if (!isLocal && moveFig.Type > 0 && moveFig.Color != c)
            {
                aTimer.Start();
                return;
            }
            Step s;
            Point scr = XYPlaceOnDesktop(e.Location);
            int i = DetectPlaceByXy(scr);
            if (i < 0)
            {
                UpdateBoard();
                aTimer.Start();
                return;
            }
            if (moveFig.Num == i)
            {
                UpdateBoard();
                aTimer.Start();
                return;
            }
            Place np = new Place(moveFig);
            np.Num = game.Places[i].Num;
            s = new Step(moveFig, game.Places[i], 1, 1, np);
            if (s.s2.Type == 1 || !ValidateStep(s))
            {
                UpdateBoard();
                aTimer.Start();
                return;
            }
            List<Step> li=new List<Step>();
            int kcur=curStep;
            if (isLocal)
            {
                for (int k = 0; k < game.History.Count; k++)
                    li.Add(game.History[k]);
                for (int j = game.History.Count - 1; j > curStep; j--)
                    game.History.RemoveAt(j);
            }
            game.History.Add(s);
            curStep = game.History.Count - 1;

            if (s.s12.Type == 1 && s.s12.Prop == 2 && s.s1.Prop == 1)
            {
                game.Places[s.s12.Num] = new Place(s.s12);
                game.Places[s.s22.Num] = new Place(s.s22);
                game.Places[s.s1.Num].Type = 0;
                game.Places[s.s2.Num].Type = 0;
            }
            else
            {
                game.Places[i] = new Place(s.s12);
                moveFig.Type = 0;
            }
            if (Check(s.s1))
            {
                ReturnStep(-1, true);
                if (isLocal)
                {
                    game.History = li;
                    curStep = kcur;
                }
            }
            if (!isLocal)
                DoStep();
            UpdateBoard();
            ViewHistory();
            aTimer.Start();
            
        }


        private void checkBoxBlack_CheckedChanged(object sender, EventArgs e)
        {
            color = checkBoxBlack.Checked ? 2 : 1;
            UpdateBoard();
        }
        //Возврат хода
        private void buttonBack_Click(object sender, EventArgs e)
        {
            ReturnStep(-1, false);           
            UpdateBoard();
            ViewHistory();
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            ReturnStep(1, false);            
            UpdateBoard();
            ViewHistory();
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            aTimer.Stop();
            //string url = "http://subdomain.test1.ru/";
            string result;
            bool isLcl = isLocal;
            isLocal = true;
            Program.form2.ShowDialog();            
            if (Program.form2.closeButton)
            {
                isLocal = isLcl;
                return;
            }
            if (label1.Text == "") {
                TestGamePosition();
                UpdateBoard();                
                ViewHistory();
                return;
            }
            using (var webClient = new WebClient())
            {
                // Создаём коллекцию параметров
                var pars = new NameValueCollection();

                // Добавляем необходимые параметры в виде пар ключ, значение                
                pars.Add("sId", label1.Text);
                pars.Add("sType", "Load");

                // Посылаем параметры на сервер
                // Может быть ответ в виде массива байт
                try
                {
                    var response = webClient.UploadValues(url, pars);
                    result = Encoding.UTF8.GetString(response); 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error:810, Ошибка соединения");
                    return;
                }
                
            }
            if (result.IndexOf("Error") == 0) {
                MessageBox.Show(result);
                return;
            }            
            isLocal = true;
            labelColor.Text = "Играем локально";
            game = JsonConvert.DeserializeObject<Part>(result);
            textBoxMessage.Text = "";
            richTextBox1.Text = game.Chat;
            richTextBox1.Select(richTextBox1.Text.Length, 0);
            richTextBox1.ScrollToCaret();
            MessageBox.Show("Партия загружена локально. ID "+label1.Text);
            UpdateBoard();
            curStep = game.Step;
            ViewHistory();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            bool isLcl = isLocal;
            string locId = label1.Text;
            isLocal = true ;
            Program.form2.ShowDialog();
            isLocal = isLcl;            
            if (Program.form2.closeButton)
            {               
                return;
            }


            List<Step> li = new List<Step>();
            
            for (int k = 0; k < game.History.Count; k++)
                li.Add(game.History[k]);
            for (int j = game.History.Count - 1; j > curStep; j--)
                game.History.RemoveAt(j);

            if (textBoxMessage.Text.Trim().Length > 0)
            {
                game.Chat += "\n" + label2.Text + ">>" + textBoxMessage.Text.Trim();
                textBoxMessage.Text = "";
                richTextBox1.Text = game.Chat;
                richTextBox1.Select(richTextBox1.Text.Length, 0);
                richTextBox1.ScrollToCaret();
            }
            aTimer.Stop();
            game.Step = curStep;
            //game.Id = label1.Text;

            string serialized = JsonConvert.SerializeObject(game);

            //string url = "http://subdomain.test1.ru/";
            string result;
            using (var webClient = new WebClient())
            {
                // Создаём коллекцию параметров
                var pars = new NameValueCollection();

                // Добавляем необходимые параметры в виде пар ключ, значение
                pars.Add("sPart", serialized);
                pars.Add("sId", label1.Text);
                pars.Add("sType", "Save");

                // Посылаем параметры на сервер
                // Может быть ответ в виде массива байт
                try
                {
                    var response = webClient.UploadValues(url, pars);
                    result = Encoding.UTF8.GetString(response); ;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error:810, Ошибка соединения");
                    game.History = li;
                    label1.Text = locId;
                    aTimer.Start();
                    return;
                }
                
            }
            if (result.IndexOf("Error") == 0)
            {
                MessageBox.Show(result);
                game.History = li;
                label1.Text = locId;
                aTimer.Start();
                return;
            }
            MessageBox.Show("Партия сохранена на текущем ходе сохранена. ID "+result+"\n Продолжайте");
            if (isLocal)
            {
                labelColor.Text = "Играем локально";            
                label1.Text = result;
            }
            else {
                label1.Text = game.Id;
            }
            game.History = li;
            aTimer.Start();
            
        }
        private void DoStep() 
        {
            //List<Step> li = new List<Step>();

           // for (int k = 0; k < game.History.Count; k++)
             //   li.Add(game.History[k]);
           // for (int j = game.History.Count - 1; j > curStep; j--)
             //   game.History.RemoveAt(j);

            if (textBoxMessage.Text.Trim().Length > 0)
                game.Chat += "\n" + label2.Text + ">>" + textBoxMessage.Text.Trim();

            game.Step = curStep;
            string serialized = JsonConvert.SerializeObject(game);

            //string url = "http://subdomain.test1.ru/";
            string result;
            using (var webClient = new WebClient())
            {
                // Создаём коллекцию параметров
                var pars = new NameValueCollection();

                // Добавляем необходимые параметры в виде пар ключ, значение
                pars.Add("sPart", serialized);
                pars.Add("sType", "Start");
                pars.Add("sId", label1.Text.Trim());

                // Посылаем параметры на сервер
                // Может быть ответ в виде массива байт
                try
                {
                    var response = webClient.UploadValues(url, pars);
                    result = Encoding.UTF8.GetString(response);
                }
                catch (Exception e)
                {
                    MessageBox.Show("Error:810, Ошибка соединения");
                    return;
                }
                
            }
            isLocal = false;
            Part res = new Part();
            res = JsonConvert.DeserializeObject<Part>(result);
            if (res.Step >= game.History.Count - 1)
            {
                game = res;
                textBoxMessage.Text = "";
            }
            else
            {
                //labelTime.Text = (fromPHPTime(res.LastTime)).ToString("dd MMM yyyy HH:mm:ss");
                return;
            }
            
            label1.Text = game.Id.ToString();
            labelTime.Text = (fromPHPTime(game.LastTime)).ToString("dd MMM yyyy HH:mm:ss");
            richTextBox1.Text = game.Chat;
            richTextBox1.Select(richTextBox1.Text.Length, 0);
            richTextBox1.ScrollToCaret();
            curStep = game.Step;
        }
        private DateTime fromPHPTime(long ticks)
        {
            DateTime unixEpoch = new DateTime(1970, 1, 1, 0, 0, 0);
            return unixEpoch.Add(new TimeSpan(0, 0, (int)ticks));
        }
        private void button1_Click(object sender, EventArgs e)
        {            
            bool isLcl=isLocal;
            isLocal = false;
            Program.form2.ShowDialog();
            if (Program.form2.closeButton){
                isLocal = isLcl;
                return;
            }
            aTimer.Stop();
            if (playBlack) {
                checkBoxBlack.Checked = true;
                color = checkBoxBlack.Checked ? 2 : 1;
                
            }
            if (label1.Text.Trim() == "")
            {
                TestGamePosition();
            }               
            DoStep();
            label1.Text = game.Id;
            
            UpdateBoard();            
            ViewHistory();
            

            aTimer.Tick += new EventHandler(OnTimedEvent);
            aTimer.Interval = 10000;
            aTimer.Start();
        }
        private void OnTimedEvent(object source, EventArgs e)
        {
            if (isLocal)
                return;           
            
            string result;
            using (var webClient = new WebClient())
            {
                // Создаём коллекцию параметров
                var pars = new NameValueCollection();

                // Добавляем необходимые параметры в виде пар ключ, значение
                pars.Add("sType", "Time");
                pars.Add("sId", label1.Text);

                // Посылаем параметры на сервер
                // Может быть ответ в виде массива байт
                try
                {
                    var response = webClient.UploadValues(url, pars);
                    result = Encoding.UTF8.GetString(response);
                }
                catch (Exception ex) {
                    if (msg.Visible = true)
                        msg.Show("Error:810, Ошибка соединения.Повтор через 60 сек. Попробуйте загрузить локально");
                    else
                    {
                        msg.ShowDialog();
                        msg.Show("Error:810, Ошибка соединения.Повтор через 60 сек. Попробуйте загрузить локально");
                    }
                    
                    aTimer.Interval = 60000;
                    return;
                }
                
            }
            aTimer.Interval = 10000;
            if (result.IndexOf("Error") == 0)
            {
                MessageBox.Show(result);
                return;
            }  
            Part res = new Part();
            res = JsonConvert.DeserializeObject<Part>(result);
            if (res.Step > game.History.Count - 1)
                game = res;
            else
                return;
           // label1.Text = game.Id.ToString();
            labelTime.Text = (fromPHPTime(game.LastTime)).ToString("dd MMM yyyy HH:mm:ss");
            richTextBox1.Text = game.Chat;
            richTextBox1.Select(richTextBox1.Text.Length, 0);
            richTextBox1.ScrollToCaret();
            curStep = game.Step;
            UpdateBoard();
            ViewHistory();
            
        }

        




    }
    public class Part
    {

        public string Id { get; set; }        
        public string Name1 { get; set; }//белые
        public string Name2 { get; set; }//черные	
        public int Step { get; set; }//чей ход 1-Name1, 2-Name2				
        public int StartTime { get; set; }
        public int LastTime { get; set; }

        public Place[] Places { get; set; }

        public Place[] StartPlaces { get; set; }

        public List<Step> History { get; set; }

        public string Chat { get; set; }
        public Part()
        {
            
            History = new List<Step>();
            Places = new Place[64];
            for (int i = 0; i < Places.Length; i++)
                Places[i] = new Place(0, 0, i, 0);
        }
    }
    public class Step
    {
        public Place s1;
        public Place s2;
        public Place s12;
        public Place s22;
        public int type;
        public int res;
        public Step(Place s1, Place s2, int type, int res, Place s12)
        {
            this.s1 = new Place(s1);
            this.s2 = new Place(s2);
            this.s12 = new Place(s12);
            this.s22 = new Place(s2);
            this.type = type;
            this.res = res;
        }
        public string getNotation()
        {
            string s = "";
            s += s1.getNotation();
            switch (type)
            {
                case 1: s += "-"; break;//Ход
                case 2: s += ":"; break;//Взятие фигуры
            }
            s += s2.getNotation();
            return s;
        }
    }
    public class Place
    {
        public int Num { get; set; }
        public int Prop { get; set; }
        public Place(Place p) { Color = p.Color; Type = p.Type; Num = p.Num; Prop = p.Prop; }
        public Place(int c, int t, int n, int pr) { Color = c; Type = t; Num = n; Prop = pr; }
        public Place() { }
        public string getNotation()
        {
            string s = "";
            switch (Type)
            {
                case 1: s = "Кр"; break;
                case 2: s = "Ф"; break;
                case 3: s = "Л"; break;
                case 4: s = "К"; break;
                case 5: s = "С"; break;
                case 6: s = "п"; break;
            }
            string alf = "ABCDEFGH";
            // alf = "HGFEDCBA";
            getY();
            return s + alf[getX()] + (8 - getY()).ToString();
        }
        public int getX()
        {
            return Num % 8;
        }
        public int getY()
        {
            return Num / 8;
        }
        public int Color { get; set; }
        public int Type { get; set; }
    }
}
